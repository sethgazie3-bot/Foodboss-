import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Bike, ChefHat, ChevronDown, Clock3, MapPin, Minus, Plus, Search, ShoppingBag, Store, Truck, UtensilsCrossed, X, CheckCircle2, PackageCheck, LayoutDashboard, CircleDollarSign, Menu as MenuIcon } from 'lucide-react';
import './styles.css';

const initialRestaurants = [
  { id: 1, name: 'Soweto Flame Grill', category: 'Braai & Grill', rating: '4.8', time: '25–35 min', fee: 18, emoji: '🍗', color: 'peach', description: 'Flame-grilled favourites and township classics', items: [
    { id: 101, name: 'Quarter Chicken & Pap', description: 'Flame-grilled chicken, pap and chakalaka', price: 89, emoji: '🍗' },
    { id: 102, name: 'Beef Kota', description: 'Loaded quarter-loaf with chips and sauce', price: 65, emoji: '🥪' },
    { id: 103, name: 'Boerewors Roll', description: 'Grilled wors, caramelised onion and relish', price: 48, emoji: '🌭' }
  ]},
  { id: 2, name: 'Maboneng Bowl Co.', category: 'Bowls & Healthy', rating: '4.7', time: '20–30 min', fee: 15, emoji: '🥗', color: 'mint', description: 'Fresh bowls, wraps and feel-good meals', items: [
    { id: 201, name: 'Chicken Avo Bowl', description: 'Grilled chicken, avo, greens and rice', price: 92, emoji: '🥗' },
    { id: 202, name: 'Crispy Halloumi Wrap', description: 'Halloumi, slaw and lemon yoghurt', price: 76, emoji: '🌯' },
    { id: 203, name: 'Mango Smoothie', description: 'Mango, banana and yoghurt', price: 35, emoji: '🥭' }
  ]},
  { id: 3, name: 'Jozi Pizza Club', category: 'Pizza', rating: '4.9', time: '30–40 min', fee: 20, emoji: '🍕', color: 'lavender', description: 'Stone-baked pizza, made fresh to order', items: [
    { id: 301, name: 'Margherita Pizza', description: 'Mozzarella, basil and tomato', price: 99, emoji: '🍕' },
    { id: 302, name: 'BBQ Chicken Pizza', description: 'BBQ chicken, red onion and mozzarella', price: 119, emoji: '🍕' },
    { id: 303, name: 'Garlic Bread', description: 'Toasted garlic and herb bread', price: 32, emoji: '🥖' }
  ]},
  { id: 4, name: 'Golden Kota Kitchen', category: 'Street Food', rating: '4.6', time: '15–25 min', fee: 12, emoji: '🍔', color: 'yellow', description: 'Big flavours, local prices', items: [
    { id: 401, name: 'Classic Kota', description: 'Atchar, chips, egg and polony', price: 45, emoji: '🍔' },
    { id: 402, name: 'Cheesy Chips', description: 'Golden chips topped with cheese sauce', price: 39, emoji: '🍟' },
    { id: 403, name: 'Chicken Gatsby Slice', description: 'Spicy chicken, chips and sauce', price: 59, emoji: '🥖' }
  ]}
];

const money = n => new Intl.NumberFormat('en-ZA', { style: 'currency', currency: 'ZAR', maximumFractionDigits: 0 }).format(n);
const seedOrders = [
  { id: 'FB-1042', customer: 'Thando M.', restaurant: 'Soweto Flame Grill', items: 'Quarter Chicken & Pap × 2', total: 196, status: 'Preparing', address: 'Orlando West, Soweto', time: '12:42' },
  { id: 'FB-1041', customer: 'Lerato K.', restaurant: 'Maboneng Bowl Co.', items: 'Chicken Avo Bowl × 1', total: 107, status: 'Ready for pickup', address: 'Maboneng, Johannesburg', time: '12:35' },
  { id: 'FB-1040', customer: 'Sipho D.', restaurant: 'Jozi Pizza Club', items: 'BBQ Chicken Pizza × 1', total: 139, status: 'Out for delivery', address: 'Braamfontein, Johannesburg', time: '12:21' }
];

function App() {
  const [role, setRole] = useState('customer');
  const [restaurants] = useState(initialRestaurants);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [selected, setSelected] = useState(null);
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [orders, setOrders] = useState(seedOrders);
  const [notice, setNotice] = useState('');
  const [mobileNav, setMobileNav] = useState(false);

  const categories = ['All', 'Braai & Grill', 'Bowls & Healthy', 'Pizza', 'Street Food'];
  const filtered = restaurants.filter(r => (category === 'All' || r.category === category) &&
    (r.name + ' ' + r.category + ' ' + r.description).toLowerCase().includes(search.toLowerCase()));
  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const deliveryFee = cart.length ? (restaurants.find(r => r.id === cart[0].restaurantId)?.fee || 0) : 0;
  const total = subtotal + deliveryFee;
  const activeOrders = orders.filter(o => !['Delivered', 'Cancelled'].includes(o.status));

  const addToCart = (restaurant, item) => {
    if (cart.length && cart[0].restaurantId !== restaurant.id) {
      setNotice('Your cart has items from another restaurant. Clear your cart first to order from this restaurant.');
      return;
    }
    setCart(old => {
      const found = old.find(x => x.id === item.id);
      return found ? old.map(x => x.id === item.id ? { ...x, qty: x.qty + 1 } : x)
        : [...old, { ...item, qty: 1, restaurantId: restaurant.id, restaurantName: restaurant.name }];
    });
    setNotice(`${item.name} added to your cart`);
    setTimeout(() => setNotice(''), 2400);
  };
  const changeQty = (id, amount) => setCart(old => old.map(x => x.id === id ? { ...x, qty: x.qty + amount } : x).filter(x => x.qty > 0));
  const placeOrder = e => {
    e.preventDefault();
    const order = {
      id: 'FB-' + (1043 + orders.length - seedOrders.length),
      customer: customerName.trim(),
      restaurant: cart[0]?.restaurantName || 'FoodBoss restaurant',
      items: cart.map(i => `${i.name} × ${i.qty}`).join(', '),
      total, status: 'New order', address: address.trim(), time: new Date().toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' })
    };
    setOrders(old => [order, ...old]);
    setCart([]);
    setCheckoutOpen(false);
    setCartOpen(false);
    setCustomerName('');
    setPhone('');
    setAddress('');
    setNotice(`Order ${order.id} placed! This is a demo order.`);
    setTimeout(() => setNotice(''), 4500);
  };
  const updateStatus = (id, status) => setOrders(old => old.map(o => o.id === id ? { ...o, status } : o));
  const roleMeta = {
    customer: { label: 'Order food', icon: ShoppingBag },
    restaurant: { label: 'Restaurant', icon: Store },
    driver: { label: 'Driver', icon: Bike }
  };

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => { setRole('customer'); setSelected(null); }} aria-label="FoodBoss home">
        <span className="brand-mark"><UtensilsCrossed size={22}/></span><span>Food<span className="brand-accent">Boss</span><small>GOOD FOOD. JOZI SPEED.</small></span>
      </button>
      <div className="location-pill"><MapPin size={16}/><span><small>DELIVERING TO</small><strong>Johannesburg, GP</strong></span><ChevronDown size={15}/></div>
      <div className="header-actions">
        <button className="cart-button" onClick={() => setCartOpen(true)}><ShoppingBag size={18}/><span>Cart</span>{cartCount > 0 && <b>{cartCount}</b>}</button>
        <button className="menu-toggle" onClick={() => setMobileNav(!mobileNav)}><MenuIcon/></button>
      </div>
    </header>

    <div className={`role-nav ${mobileNav ? 'show-mobile' : ''}`}>
      <span className="nav-label">DEMO VIEW</span>
      {Object.entries(roleMeta).map(([key, meta]) => { const Icon = meta.icon; return <button key={key} className={`role-tab ${role === key ? 'active' : ''}`} onClick={() => { setRole(key); setSelected(null); setMobileNav(false); }}><Icon size={17}/>{meta.label}</button>; })}
      <span className="demo-pill"><span/> DEMO MODE</span>
    </div>

    <main>
      {role === 'customer' && <CustomerView restaurants={filtered} allRestaurants={restaurants} categories={categories} category={category} setCategory={setCategory} search={search} setSearch={setSearch} selected={selected} setSelected={setSelected} addToCart={addToCart} />}
      {role === 'restaurant' && <RestaurantView orders={orders} updateStatus={updateStatus} />}
      {role === 'driver' && <DriverView orders={orders} updateStatus={updateStatus} />}
    </main>

    <footer><span>© 2026 FoodBoss · Johannesburg, South Africa</span><span>Prices in ZAR · Prototype only</span></footer>

    {notice && <div className="toast"><CheckCircle2 size={18}/>{notice}<button onClick={() => setNotice('')}><X size={15}/></button></div>}

    {cartOpen && <div className="overlay" onMouseDown={e => e.target === e.currentTarget && setCartOpen(false)}>
      <section className="drawer">
        <div className="drawer-head"><div><span className="eyebrow">YOUR ORDER</span><h2>Your cart <span className="muted">({cartCount})</span></h2></div><button className="icon-btn" onClick={() => setCartOpen(false)}><X/></button></div>
        {!cart.length ? <div className="empty-state"><span className="empty-emoji">🛍️</span><h3>Your cart is waiting</h3><p>Add a meal from a local favourite to get started.</p><button className="primary-btn" onClick={() => setCartOpen(false)}>Explore restaurants</button></div> :
        <><div className="cart-items">{cart.map(item => <div className="cart-row" key={item.id}><span className="food-emoji small">{item.emoji}</span><div className="cart-item-copy"><strong>{item.name}</strong><small>{item.restaurantName}</small><b>{money(item.price * item.qty)}</b></div><QtyControl qty={item.qty} change={amount => changeQty(item.id, amount)}/></div>)}</div>
        <div className="bill"><div><span>Subtotal</span><b>{money(subtotal)}</b></div><div><span>Delivery fee</span><b>{money(deliveryFee)}</b></div><div className="bill-total"><span>Total</span><strong>{money(total)}</strong></div></div>
        <button className="primary-btn full" onClick={() => { setCartOpen(false); setCheckoutOpen(true); }}>Continue to checkout <span>· {money(total)}</span></button><button className="text-btn full" onClick={() => setCart([])}>Clear cart</button></>}
      </section>
    </div>}

    {checkoutOpen && <div className="overlay" onMouseDown={e => e.target === e.currentTarget && setCheckoutOpen(false)}>
      <section className="checkout-modal">
        <div className="drawer-head"><div><span className="eyebrow">ALMOST THERE</span><h2>Checkout</h2></div><button className="icon-btn" onClick={() => setCheckoutOpen(false)}><X/></button></div>
        <div className="checkout-summary"><span>{cartCount} item{cartCount === 1 ? '' : 's'}</span><strong>{money(total)}</strong></div>
        <form onSubmit={placeOrder} className="checkout-form">
          <label>Full name<input required value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="e.g. Thando Mokoena"/></label>
          <label>Mobile number<input required type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="e.g. 082 123 4567"/></label>
          <label>Delivery address<input required value={address} onChange={e => setAddress(e.target.value)} placeholder="Street, suburb, Johannesburg"/></label>
          <div className="demo-notice">Demo checkout only. No payment is collected and no driver is dispatched.</div>
          <button className="primary-btn full" type="submit">Place demo order · {money(total)}</button>
        </form>
      </section>
    </div>}
  </div>;
}

function QtyControl({ qty, change }) {
  return <div className="qty-control"><button onClick={() => change(-1)} aria-label="Decrease quantity"><Minus size={13}/></button><span>{qty}</span><button onClick={() => change(1)} aria-label="Increase quantity"><Plus size={13}/></button></div>;
}

function CustomerView({ restaurants, allRestaurants, categories, category, setCategory, search, setSearch, selected, setSelected, addToCart }) {
  const [sort, setSort] = useState('popular');
  const chosen = allRestaurants.find(r => r.id === selected);
  const sorted = [...restaurants].sort((a,b) => sort === 'rating' ? Number(b.rating)-Number(a.rating) : sort === 'fee' ? a.fee-b.fee : a.id-b.id);
  if (chosen) return <div className="content-wrap">
    <button className="back-link" onClick={() => setSelected(null)}>← All restaurants</button>
    <div className={`restaurant-hero ${chosen.color}`}><div className="restaurant-hero-emoji">{chosen.emoji}</div><div><span className="eyebrow">{chosen.category}</span><h1>{chosen.name}</h1><p>{chosen.description}</p><div className="meta-line"><span>★ {chosen.rating}</span><span><Clock3 size={14}/>{chosen.time}</span><span>Delivery {money(chosen.fee)}</span></div></div></div>
    <div className="section-head"><div><span className="eyebrow">MADE FRESH</span><h2>Menu</h2></div><span className="subtle-text">{chosen.items.length} favourites</span></div>
    <div className="menu-list">{chosen.items.map(item => <div className="menu-item" key={item.id}><div className="food-emoji">{item.emoji}</div><div className="menu-copy"><h3>{item.name}</h3><p>{item.description}</p><strong>{money(item.price)}</strong></div><button className="add-btn" onClick={() => addToCart(chosen, item)}><Plus size={17}/> Add</button></div>)}</div>
  </div>;

  return <div className="content-wrap">
    <section className="hero">
      <div className="hero-copy"><span className="hero-kicker"><span className="sparkle">✦</span> JOZI'S LOCAL FOOD SCENE</span><h1>Big flavour.<br/><span>Right to your door.</span></h1><p>From township classics to your new favourite bowl — find something good today.</p><div className="hero-search"><Search size={19}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search meals or restaurants..."/>{search && <button onClick={() => setSearch('')}><X size={16}/></button>}</div><div className="hero-foot"><span><CheckCircle2 size={15}/> Local favourites</span><span><CheckCircle2 size={15}/> Prices in rand</span></div></div>
      <div className="hero-art"><div className="art-orbit orbit-one"></div><div className="art-orbit orbit-two"></div><div className="hero-food">🍔</div><span className="floating-food f1">🍟</span><span className="floating-food f2">🍕</span><span className="floating-food f3">🥤</span><div className="art-sticker">MADE<br/>FOR JOZI <span>♥</span></div></div>
    </section>
    <div className="section-head restaurant-heading"><div><span className="eyebrow">WHAT ARE YOU CRAVING?</span><h2>Explore restaurants</h2></div><label className="sort-select">Sort by <select value={sort} onChange={e => setSort(e.target.value)}><option value="popular">Popular</option><option value="rating">Top rated</option><option value="fee">Lowest delivery fee</option></select></label></div>
    <div className="category-row">{categories.map(c => <button key={c} onClick={() => setCategory(c)} className={`category-chip ${category === c ? 'selected' : ''}`}>{c === 'All' ? '🍽️' : c === 'Braai & Grill' ? '🔥' : c === 'Bowls & Healthy' ? '🥗' : c === 'Pizza' ? '🍕' : '🥪'} <span>{c}</span></button>)}</div>
    {sorted.length ? <div className="restaurant-grid">{sorted.map(r => <button className="restaurant-card" key={r.id} onClick={() => setSelected(r.id)}><div className={`card-art ${r.color}`}><span className="card-emoji">{r.emoji}</span><span className="rating">★ {r.rating}</span><span className="card-tag">{r.category}</span></div><div className="card-body"><div className="card-title-row"><h3>{r.name}</h3><span className="arrow-circle">↗</span></div><p>{r.description}</p><div className="card-meta"><span><Clock3 size={14}/>{r.time}</span><span>Delivery {money(r.fee)}</span></div></div></button>)}</div> : <div className="empty-search"><span>🔎</span><h3>No matches just yet</h3><p>Try a different search or category.</p><button className="text-btn" onClick={() => { setSearch(''); setCategory('All'); }}>Clear filters</button></div>}
    <section className="promo-strip"><div className="promo-icon">🛵</div><div><strong>Local food, local love.</strong><p>Discover independent kitchens around Johannesburg.</p></div><span className="promo-label">#EATJOZI</span></section>
  </div>;
}

function RestaurantView({ orders, updateStatus }) {
  const [filter, setFilter] = useState('All');
  const visible = orders.filter(o => filter === 'All' || o.status === filter);
  const newCount = orders.filter(o => ['New order', 'Preparing'].includes(o.status)).length;
  const sales = orders.filter(o => o.status !== 'Cancelled').reduce((n,o) => n + o.total, 0);
  const nextStatus = status => status === 'New order' ? ['Accept order', 'Preparing'] : status === 'Preparing' ? ['Mark ready', 'Ready for pickup'] : status === 'Ready for pickup' ? ['Hand to driver', 'Out for delivery'] : null;
  return <div className="content-wrap dashboard-wrap">
    <div className="dashboard-heading"><div><span className="eyebrow">PARTNER SPACE</span><h1>Restaurant dashboard</h1><p>Manage incoming orders and keep your kitchen moving.</p></div><div className="partner-badge"><span className="live-dot"/> Kitchen demo</div></div>
    <div className="stats-grid"><Stat icon={<ShoppingBag/>} label="Active orders" value={String(orders.filter(o => !['Delivered','Cancelled'].includes(o.status)).length)} detail={`${newCount} need attention`}/><Stat icon={<CircleDollarSign/>} label="Order value" value={money(sales)} detail="Demo order total"/><Stat icon={<Clock3/>} label="Avg. prep target" value="25 min" detail="Set your own hours soon"/></div>
    <div className="section-head"><div><span className="eyebrow">KITCHEN QUEUE</span><h2>Orders</h2></div><label className="sort-select">Show <select value={filter} onChange={e => setFilter(e.target.value)}><option>All</option><option>New order</option><option>Preparing</option><option>Ready for pickup</option><option>Out for delivery</option><option>Delivered</option></select></label></div>
    <div className="orders-list">{visible.map(order => { const next = nextStatus(order.status); return <article className="order-card" key={order.id}><div className="order-top"><div><span className="order-id">{order.id}</span><h3>{order.restaurant}</h3><p>{order.items}</p></div><Status status={order.status}/></div><div className="order-details"><span><Clock3 size={15}/>{order.time}</span><span><MapPin size={15}/>{order.address}</span><strong>{money(order.total)}</strong></div><div className="order-actions">{next && <button className="primary-btn compact" onClick={() => updateStatus(order.id, next[1])}>{next[0]} <span>→</span></button>}{order.status === 'Out for delivery' && <span className="muted-action">Driver has the order</span>}{order.status === 'Delivered' && <span className="done-label"><CheckCircle2 size={16}/> Completed</span>}</div></article>; })}{!visible.length && <div className="empty-search"><h3>No orders in this view</h3><p>Try selecting a different status.</p></div>}</div>
    <p className="prototype-note"><ChefHat size={16}/> Demo data is shared between the customer, restaurant and driver views in this browser session.</p>
  </div>;
}

function DriverView({ orders, updateStatus }) {
  const jobs = orders.filter(o => ['Ready for pickup', 'Out for delivery'].includes(o.status));
  const delivered = orders.filter(o => o.status === 'Delivered').length;
  return <div className="content-wrap dashboard-wrap">
    <div className="dashboard-heading"><div><span className="eyebrow">DRIVER SPACE</span><h1>Your delivery run</h1><p>Pickup, deliver and keep customers in the loop.</p></div><div className="driver-avatar"><Bike size={23}/></div></div>
    <div className="driver-summary"><div className="driver-summary-icon"><Truck size={25}/></div><div><strong>{jobs.length} active job{jobs.length === 1 ? '' : 's'}</strong><p>{delivered} demo delivery{delivered === 1 ? '' : 'ies'} completed</p></div><span className="driver-route">JOHANNESBURG · GP</span></div>
    <div className="section-head"><div><span className="eyebrow">YOUR TASKS</span><h2>Delivery queue</h2></div><span className="subtle-text">{jobs.length} waiting or in transit</span></div>
    <div className="orders-list">{jobs.map(order => <article className="delivery-card" key={order.id}><div className="delivery-timeline"><div className={`timeline-dot ${order.status === 'Out for delivery' ? 'current' : ''}`}></div><div className="timeline-line"></div><div className="timeline-dot"></div></div><div className="delivery-main"><div className="order-top"><div><span className="order-id">{order.id}</span><h3>{order.restaurant}</h3><p>{order.items}</p></div><Status status={order.status}/></div><div className="delivery-stop"><span className="stop-icon pickup"><Store size={16}/></span><div><small>PICKUP FROM</small><strong>{order.restaurant}</strong></div></div><div className="delivery-stop"><span className="stop-icon drop"><MapPin size={16}/></span><div><small>DELIVER TO</small><strong>{order.address}</strong><span className="customer-name">{order.customer}</span></div></div><div className="delivery-bottom"><span className="delivery-payout">Order total <strong>{money(order.total)}</strong></span>{order.status === 'Ready for pickup' ? <button className="primary-btn compact" onClick={() => updateStatus(order.id, 'Out for delivery')}>Picked up <span>→</span></button> : <button className="primary-btn compact" onClick={() => updateStatus(order.id, 'Delivered')}>Mark delivered <span>✓</span></button>}</div></div></article>)}{!jobs.length && <div className="empty-search"><span>🛵</span><h3>All caught up</h3><p>New delivery tasks will show up here when orders are ready.</p></div>}</div>
    <p className="prototype-note"><PackageCheck size={16}/> Route navigation, proof of delivery and driver payouts are not connected in this prototype.</p>
  </div>;
}

function Stat({ icon, label, value, detail }) { return <div className="stat-card"><div className="stat-top"><span className="stat-icon">{icon}</span><span className="stat-label">{label}</span></div><strong className="stat-value">{value}</strong><span className="stat-detail">{detail}</span></div>; }
function Status({ status }) { const cls = status.toLowerCase().replaceAll(' ', '-'); return <span className={`status status-${cls}`}>{status}</span>; }

createRoot(document.getElementById('root')).render(<App />);
